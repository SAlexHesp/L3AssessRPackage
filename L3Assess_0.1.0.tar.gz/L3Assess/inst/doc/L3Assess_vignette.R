## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = FALSE)

## ----library_setup------------------------------------------------------------
library(L3Assess)
Fig_Path = "C:/~/L3AssessPackage/vignettes/"

